package br.pro.appagenda_2020_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etTelefone;
    private Spinner spCidade, spEstado;
    private RadioButton rbFeminino, rbMasculino;
    private CheckBox cbEmail;
    private Button btnSalvar;

    @Override

    //Primeiro método a ser chamado
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);//arquivo da view

        //(EditText) casting opcional
        etNome      = (EditText) findViewById(R.id.etNome);
        etTelefone  = findViewById(R.id.etTelefone);
        spCidade    = findViewById(R.id.spCidade);
        spEstado    = findViewById(R.id.spEstado);
        rbFeminino  = findViewById(R.id.rbFeminino);
        rbMasculino = findViewById(R.id.rbMasculino);
        cbEmail     = findViewById(R.id.cbAceitaEmail);
        btnSalvar   = findViewById(R.id.btnSalvar);


    }

    private void salvar() {
        String texto = "";
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }
}

//Notes

//onCreate -> onStart(iniciou) ->onResume(usuarioTemAcessoAqui)
//onPause (paraEaTENDE) ->onRestart() -> onResume(voltou)


//receita de bolo: classe, xml , ligação  setContentView(R.layout.activity_main);//arquivo da view
//registrar activity no manifest



